"""
HAxBRO Brain - Simple web server
Real model + professional UI. Easy to upgrade later.
"""
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional

from brain_api import ask, info

app = FastAPI(title="HAxBRO Brain", version="0.1.0")
UI_DIR = Path(__file__).parent / "ui"

class ChatRequest(BaseModel):
    message: str
    user_id: Optional[str] = "default"

@app.get("/", response_class=HTMLResponse)
async def home():
    html = (UI_DIR / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)

@app.get("/api/info")
async def api_info():
    return info()

@app.post("/api/chat")
async def api_chat(req: ChatRequest):
    if not req.message or not req.message.strip():
        return JSONResponse({"error": "Empty message"}, status_code=400)
    result = ask(req.message.strip(), user_id=req.user_id or "default")
    return result

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "HAxBRO-Brain"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
