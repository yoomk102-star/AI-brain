"""
HAxBRO Brain — Intelligence Provider Contract
Compatible with the integration interface from the HAxBRO audit.

This is the stable API that main HAxBRO / App Maker / workspaces should call.
Matches the conceptual IntelligenceProvider design from the technical audit.
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field, asdict
import time

from core.brain import Brain


@dataclass
class BrainMessage:
    role: str  # system | user | assistant
    content: str


@dataclass
class BrainRequest:
    prompt: str
    history: Optional[List[Dict[str, str]]] = None
    memory: Optional[str] = None
    task: Optional[str] = None
    difficulty: Optional[str] = None  # easy | medium | hard | expert
    context: Optional[Dict[str, Any]] = None
    user_id: str = "default"
    session_id: str = "default"


@dataclass
class BrainResult:
    ok: bool
    response: str
    provider: str = "haxbro-brain"
    model: Optional[str] = None
    elapsed_ms: Optional[float] = None
    sources: Optional[List[Dict[str, str]]] = None
    error: Optional[str] = None
    # Extra diagnostics (safe to expose)
    task_type: Optional[str] = None
    difficulty: Optional[str] = None
    algorithm_steps: Optional[List[str]] = None
    understood: Optional[bool] = None


class HaxbroBrainProvider:
    """
    Stable provider that HAxBRO can register as a model lane
    (e.g. "brain" / "haxbro-brain") next to local / github / largest / lite.
    """

    id = "haxbro-brain"

    def __init__(self):
        self._brain = Brain()

    def info(self) -> Dict[str, Any]:
        base = self._brain.info()
        return {
            "id": self.id,
            "provider": "haxbro-brain",
            "name": base.get("name"),
            "version": base.get("version"),
            "neural": base.get("neural"),
            "algorithms": base.get("algorithms"),
            "difficulty_levels": base.get("difficulty_levels"),
            "tools": base.get("tools"),
            "behavior": base.get("behavior"),
            "contract": "BrainRequest / BrainResult",
            "integration": {
                "browser_direct": False,
                "python_service": True,
                "onnx_export": "not yet",
                "recommended_lane_name": "brain",
            },
        }

    def is_available(self) -> bool:
        try:
            _ = self._brain.model.count_parameters()
            return True
        except Exception:
            return False

    def ask(self, request: BrainRequest) -> BrainResult:
        start = time.time()
        try:
            # Merge optional history into session by replaying lightly
            # (Brain already has conversation memory keyed by session_id)
            result = self._brain.think(
                request.prompt,
                user_id=request.user_id,
                session_id=request.session_id,
            )
            elapsed = (time.time() - start) * 1000
            ok = bool(result.get("understood", True)) or bool(result.get("answer"))
            return BrainResult(
                ok=ok,
                response=result.get("answer") or "",
                provider=self.id,
                model=f"HAxBRO-Brain-{result.get('model_info', {}).get('parameters', 0)}",
                elapsed_ms=round(elapsed, 1),
                sources=result.get("sources") or [],
                task_type=result.get("task_type"),
                difficulty=result.get("difficulty"),
                algorithm_steps=result.get("algorithm_steps"),
                understood=result.get("understood"),
            )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return BrainResult(
                ok=False,
                response="",
                provider=self.id,
                elapsed_ms=round(elapsed, 1),
                error=str(e),
            )

    def ask_dict(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """HTTP-friendly entry: accepts plain dict, returns plain dict."""
        req = BrainRequest(
            prompt=payload.get("prompt") or payload.get("message") or payload.get("query") or "",
            history=payload.get("history"),
            memory=payload.get("memory"),
            task=payload.get("task"),
            difficulty=payload.get("difficulty"),
            context=payload.get("context"),
            user_id=payload.get("user_id") or payload.get("username") or "default",
            session_id=payload.get("session_id") or payload.get("kaiId") or "default",
        )
        if not req.prompt.strip():
            return asdict(BrainResult(ok=False, response="", error="Empty prompt", provider=self.id))
        return asdict(self.ask(req))


# Singleton for simple imports
_provider: Optional[HaxbroBrainProvider] = None

def get_provider() -> HaxbroBrainProvider:
    global _provider
    if _provider is None:
        _provider = HaxbroBrainProvider()
    return _provider
