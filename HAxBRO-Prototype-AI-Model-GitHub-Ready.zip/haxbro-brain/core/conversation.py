"""
Working conversation memory (session-level).
Keeps recent turns so the brain can reply in context.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict
from datetime import datetime, timezone


@dataclass
class Turn:
    role: str  # user | assistant
    content: str
    difficulty: str = ""
    task_type: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ConversationMemory:
    def __init__(self, max_turns: int = 20):
        self.max_turns = max_turns
        self.sessions: Dict[str, List[Turn]] = {}

    def add(self, session_id: str, role: str, content: str, difficulty: str = "", task_type: str = ""):
        if session_id not in self.sessions:
            self.sessions[session_id] = []
        self.sessions[session_id].append(Turn(role=role, content=content, difficulty=difficulty, task_type=task_type))
        if len(self.sessions[session_id]) > self.max_turns:
            self.sessions[session_id] = self.sessions[session_id][-self.max_turns:]

    def recent(self, session_id: str, n: int = 6) -> List[Dict]:
        turns = self.sessions.get(session_id, [])[-n:]
        return [{"role": t.role, "content": t.content} for t in turns]

    def summary(self, session_id: str) -> str:
        turns = self.sessions.get(session_id, [])
        if not turns:
            return "No previous conversation."
        lines = []
        for t in turns[-4:]:
            lines.append(f"{t.role}: {t.content[:120]}")
        return "\n".join(lines)
