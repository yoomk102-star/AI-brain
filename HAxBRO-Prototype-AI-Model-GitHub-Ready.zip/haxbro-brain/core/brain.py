"""
HAxBRO Brain - Conversational intelligence layer
Real neural core + algorithms + difficulty + conversation memory + web tools.
Designed for direct chat.
"""
from __future__ import annotations
from typing import Dict, Any, Optional, List
from pathlib import Path
import re
import torch

from core.model import HaxbroBrain
from core.algorithms import TaskAnalyzer, TaskAnalysis, Difficulty, TaskType, DIFFICULTY_CONFIG
from core.conversation import ConversationMemory
from memory.store import LocalMemory
from tools.web import WebTools, SearchResult
from core.knowledge import lookup


class Brain:
    def __init__(self, checkpoint_dir: str = "checkpoints"):
        self.memory = LocalMemory()
        self.conversation = ConversationMemory(max_turns=24)
        self.web = WebTools()
        self.analyzer = TaskAnalyzer()
        # Load the bundled checkpoint with its exact architecture. The previous
        # code instantiated a different, larger model and never loaded these weights.
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path = Path(__file__).resolve().parent.parent / "checkpoints" / "haxbro_brain_trained.pt"
        self.checkpoint_config = None
        self.token_to_id = None
        self.id_to_token = None
        model_config = {"vocab_size": 128, "n_embd": 384, "n_head": 6, "n_layer": 8, "block_size": 256}
        checkpoint = None
        if self.checkpoint_path.is_file():
            try:
                checkpoint = torch.load(self.checkpoint_path, map_location="cpu", weights_only=True)
            except TypeError:  # compatibility with older PyTorch versions
                checkpoint = torch.load(self.checkpoint_path, map_location="cpu")
            except Exception as exc:
                print(f"Warning: checkpoint could not be loaded: {exc}")
                checkpoint = None
        if isinstance(checkpoint, dict) and isinstance(checkpoint.get("config"), dict):
            cfg = checkpoint["config"]
            model_config = {k: int(cfg[k]) for k in ("vocab_size", "n_embd", "n_head", "n_layer", "block_size") if k in cfg}
            self.checkpoint_config = cfg
            self.token_to_id = cfg.get("stoi")
            self.id_to_token = {int(k): v for k, v in cfg.get("itos", {}).items()} if isinstance(cfg.get("itos"), dict) else None

        self.device = torch.device("cpu")
        self.model = HaxbroBrain(**model_config).to(self.device)
        if isinstance(checkpoint, dict) and isinstance(checkpoint.get("model_state"), dict):
            try:
                self.model.load_state_dict(checkpoint["model_state"], strict=True)
                self.checkpoint_loaded = True
            except Exception as exc:
                self.checkpoint_loaded = False
                print(f"Warning: checkpoint weights did not match model: {exc}")
        else:
            self.checkpoint_loaded = False
        self.model.eval()

    def info(self) -> Dict[str, Any]:
        return {
            "name": "HAxBRO-Brain",
            "version": "0.4.0",
            "neural": {**self.model.get_info(), "checkpoint_loaded": self.checkpoint_loaded, "checkpoint_file": self.checkpoint_path.name if self.checkpoint_loaded else None},
            "algorithms": ["task classification", "difficulty levels", "step planning", "conversation context"],
            "difficulty_levels": ["easy", "medium", "hard", "expert"],
            "memory": {
                "persistent": "multi-user local (empty until owner wires data)",
                "conversation": "session working memory (last 24 turns)",
            },
            "tools": ["web_search", "local_memory", "conversation_memory"],
            "behavior": "direct conversation · honest when unsure",
        }

    def think(self, user_message: str, user_id: str = "default", session_id: str = "default") -> Dict[str, Any]:
        msg = user_message.strip()
        if not msg:
            return self._out("Please type a message.", understood=False)

        # Conversation context
        recent = self.conversation.recent(session_id, n=6)
        self.conversation.add(session_id, "user", msg)

        analysis = self.analyzer.analyze(msg)
        config = DIFFICULTY_CONFIG[analysis.difficulty]
        memory_context = self.memory.get_context_for_user(user_id)
        used_memory = "No stored" not in memory_context

        # --- Easy paths ---
        if analysis.task_type == TaskType.GREETING:
            answer = self._greeting(recent)
            return self._finish(session_id, answer, True, analysis, used_memory=used_memory)

        if analysis.task_type == TaskType.IDENTITY:
            answer = self._identity()
            return self._finish(session_id, answer, True, analysis)

        if analysis.task_type == TaskType.CALCULATION:
            answer, ok = self._calc(msg)
            return self._finish(session_id, answer, ok, analysis)

        # --- Hard / Expert: planning & building ---
        if analysis.task_type in (TaskType.PLANNING, TaskType.BUILD) or analysis.needs_plan:
            answer = self._plan(analysis)
            return self._finish(session_id, answer, True, analysis)

        # --- Research ---
        # Prefer local structured knowledge for known technical topics
        if analysis.task_type in (TaskType.EXPLANATION, TaskType.UNKNOWN, TaskType.RESEARCH):
            kb = lookup(msg)
            if kb:
                return self._finish(session_id, kb, True, analysis)

        if analysis.task_type == TaskType.RESEARCH or analysis.needs_web:
            answer, sources, ok = self._research(msg)
            return self._finish(session_id, answer, ok, analysis, used_web=True, sources=sources)

        # --- Memory ---
        if analysis.task_type == TaskType.MEMORY:
            answer = f"From local memory:\n{memory_context}"
            return self._finish(session_id, answer, True, analysis, used_memory=True)

        # --- Conversational / general ---
        answer = self._converse(msg, recent, analysis)
        understood = analysis.task_type != TaskType.UNKNOWN or self._looks_coherent(msg)
        return self._finish(session_id, answer, understood, analysis, used_memory=used_memory)

    # ---------- response helpers ----------

    def _greeting(self, recent: List[Dict]) -> str:
        if recent:
            return "Hey again. What would you like to work on?"
        info = self.model.get_info()
        checkpoint_state = "loaded" if self.checkpoint_loaded else "not loaded"
        return (
            "Hey. I'm HAxBRO Brain.\n"
            f"My experimental local neural core has {info['parameters']:,} parameters (checkpoint {checkpoint_state}).\n"
            "I also have local task algorithms, conversation context, arithmetic, and a web-research tool. "
            "My general language ability is still experimental; ask me to research when a question needs current facts."
        )

    def _identity(self) -> str:
        info = self.model.get_info()
        return (
            f"I'm **HAxBRO Brain** — an experimental, locally operated AI project.\n\n"
            f"**Neural core:** {info['parameters']:,} trainable parameters "
            f"({info['n_layer']} layers, {info['n_embd']} dim; checkpoint {'loaded' if self.checkpoint_loaded else 'not loaded'})\n"
            f"**Algorithms:** Easy → Expert difficulty levels with different strategies\n"
            f"**Memory:** Conversation memory (this chat) + local user memory (you can fill later)\n"
            f"**Tools:** Live web research\n\n"
            f"I answer clearly. If I don't know something, I say so."
        )

    def _calc(self, msg: str) -> tuple:
        # Small recursive-descent arithmetic parser: no eval, names, calls, or attributes.
        expr = re.sub(r"(?i)\b(calculate|compute|what is|what's)\b", "", msg).strip().rstrip("?=").strip()
        if not expr or len(expr) > 180:
            return "I need a clearer, shorter arithmetic expression.", False
        if re.search(r"[^0-9+\-*/().%\s]", expr):
            return "I couldn't safely evaluate that expression. Use numbers and +, -, *, /, %, and parentheses.", False
        tokens = re.findall(r"\d+(?:\.\d+)?|[()+\-*/%]", expr)
        if "".join(tokens).replace(".", "") != re.sub(r"\s+", "", expr).replace(".", ""):
            return "I couldn't parse that expression safely.", False
        pos = 0
        def atom():
            nonlocal pos
            if pos >= len(tokens): raise ValueError("missing value")
            tok = tokens[pos]; pos += 1
            if tok in ("+", "-"):
                value = atom()
                return value if tok == "+" else -value
            if tok == "(":
                value = addsub()
                if pos >= len(tokens) or tokens[pos] != ")": raise ValueError("missing )")
                pos += 1
                return value
            if tok == ")": raise ValueError("unexpected )")
            return float(tok) if "." in tok else int(tok)
        def muldiv():
            nonlocal pos
            value = atom()
            while pos < len(tokens) and tokens[pos] in ("*", "/", "%"):
                op = tokens[pos]; pos += 1; rhs = atom()
                value = value * rhs if op == "*" else value / rhs if op == "/" else value % rhs
            return value
        def addsub():
            nonlocal pos
            value = muldiv()
            while pos < len(tokens) and tokens[pos] in ("+", "-"):
                op = tokens[pos]; pos += 1; rhs = muldiv()
                value = value + rhs if op == "+" else value - rhs
            return value
        try:
            result = addsub()
            if pos != len(tokens): raise ValueError("extra tokens")
            if isinstance(result, float) and result.is_integer(): result = int(result)
            return f"**{result}**\n\n_Calculated with the local arithmetic tool._", True
        except Exception:
            return "I couldn't safely evaluate that expression (it may be malformed or divide by zero).", False

    def _plan(self, analysis: TaskAnalysis) -> str:
        lines = [
            f"**{analysis.task_type.value.upper()}** · Difficulty: **{analysis.difficulty.value}**",
            f"_{analysis.reason}_",
            "",
            "**Execution plan:**",
        ]
        for i, step in enumerate(analysis.steps, 1):
            lines.append(f"{i}. {step}")
        lines.append("")
        if analysis.difficulty == Difficulty.EXPERT:
            lines.extend([
                "**Expert product blueprint:**",
                "• Components: UI layer, state/logic, data, optional API",
                "• Interactions: inputs, transitions, error states, mobile layout",
                "• Verification: build check, core user flow, edge cases",
                "• Delivery: self-contained HTML/JS first; split files if needed",
                "",
                "Next: give a concrete product name or constraints and I will tighten",
                "the architecture into implementable modules for App Maker.",
            ])
        elif analysis.difficulty == Difficulty.HARD:
            lines.extend([
                "**Hard-mode notes:**",
                "• Ordered steps above are the working sequence",
                "• Call out assumptions and missing requirements early",
                "• Prefer measurable checkpoints over vague progress",
                "",
                "Say which step to expand and I will go deeper.",
            ])
        else:
            lines.append("I can refine any step — say which part.")
        return "\n".join(lines)

    def _research(self, msg: str) -> tuple:
        query = re.sub(
            r"(?i)(search for|look up|research|find information about|what is|who is)\s*",
            "", msg
        ).strip() or msg
        result: SearchResult = self.web.search(query, max_results=5)
        if result.status == "ok" and result.sources:
            lines = [f"I searched for **{query}**:\n"]
            sources = []
            for i, s in enumerate(result.sources, 1):
                lines.append(f"**{i}. {s.title}**\n{s.excerpt[:220]}...\n🔗 {s.url}\n")
                sources.append({"title": s.title, "url": s.url, "domain": s.domain, "excerpt": s.excerpt})
            lines.append("_Sources are live from the web._")
            return "\n".join(lines), sources, True
        return (
            f"I tried to research “{query}” but couldn't get reliable results "
            f"({result.error or result.status}). I don't want to guess.",
            [], False
        )

    def _converse(self, msg: str, recent: List[Dict], analysis: TaskAnalysis) -> str:
        """Natural conversation path — knowledge first, then honest limits."""
        lower = msg.lower()

        # Structured knowledge (makes the brain feel smarter on core topics)
        kb = lookup(msg)
        if kb:
            return kb

        if recent and any(w in lower for w in ["yes", "ok", "continue", "go on", "next", "more"]):
            return (
                "Continuing from the last topic.\n"
                "Give the next concrete step, or ask me to research / plan / build something specific."
            )

        if any(w in lower for w in ["thanks", "thank you", "cool", "nice"]):
            return "You're welcome. What should we tackle next?"

        if any(w in lower for w in ["help", "what can you"]):
            return self._identity()

        if analysis.difficulty in (Difficulty.EASY, Difficulty.MEDIUM):
            return (
                f"I classified this as **{analysis.task_type.value}** "
                f"(difficulty: {analysis.difficulty.value}).\n\n"
                "I can:\n"
                "• Explain attention, transformers, training, App Maker flow\n"
                "• **Search** the web for live sources\n"
                "• **Plan** or **build** (hard/expert algorithms)\n"
                "• Calculate deterministically\n\n"
                "Ask a direct question or say research / plan / build."
            )

        return (
            f"Classified as **{analysis.task_type.value}** / **{analysis.difficulty.value}**.\n"
            "I don't have a reliable full answer from current knowledge and tools. "
            "Ask me to **research** it, or rephrase with more detail."
        )

    def _looks_coherent(self, msg: str) -> bool:
        return len(msg) > 2 and not re.fullmatch(r"[^a-zA-Z0-9]+", msg)

    def _finish(
        self,
        session_id: str,
        answer: str,
        understood: bool,
        analysis: TaskAnalysis,
        used_web: bool = False,
        used_memory: bool = False,
        sources: Optional[List] = None,
    ) -> Dict[str, Any]:
        self.conversation.add(
            session_id, "assistant", answer,
            difficulty=analysis.difficulty.value,
            task_type=analysis.task_type.value,
        )
        return self._out(
            answer,
            understood=understood,
            analysis=analysis,
            used_web=used_web,
            used_memory=used_memory,
            sources=sources or [],
        )

    def _out(
        self,
        answer: str,
        understood: bool = True,
        analysis: Optional[TaskAnalysis] = None,
        used_web: bool = False,
        used_memory: bool = False,
        sources: Optional[List] = None,
    ) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "answer": answer,
            "understood": understood,
            "used_web": used_web,
            "used_memory": used_memory,
            "sources": sources or [],
            "model_info": {**self.model.get_info(), "checkpoint_loaded": self.checkpoint_loaded},
        }
        if analysis:
            out["task_type"] = analysis.task_type.value
            out["difficulty"] = analysis.difficulty.value
            out["algorithm_steps"] = analysis.steps
            out["reason"] = analysis.reason
        return out

    def close(self):
        self.web.close()
