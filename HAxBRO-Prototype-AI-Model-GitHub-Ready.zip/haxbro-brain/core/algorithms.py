"""
HAxBRO Brain - Task Algorithms & Difficulty Levels
Different strategies for different kinds of work.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import re


class Difficulty(str, Enum):
    EASY = "easy"           # greetings, simple facts, basic calc
    MEDIUM = "medium"       # research, short explanations, single-tool
    HARD = "hard"           # multi-step, planning, comparison
    EXPERT = "expert"       # complex building, deep analysis, multi-tool


class TaskType(str, Enum):
    GREETING = "greeting"
    IDENTITY = "identity"
    CALCULATION = "calculation"
    RESEARCH = "research"
    EXPLANATION = "explanation"
    PLANNING = "planning"
    BUILD = "build"             # app / game / code related
    MEMORY = "memory"
    UNKNOWN = "unknown"


@dataclass
class TaskAnalysis:
    task_type: TaskType
    difficulty: Difficulty
    needs_web: bool = False
    needs_memory: bool = False
    needs_plan: bool = False
    steps: List[str] = field(default_factory=list)
    reason: str = ""


class TaskAnalyzer:
    """Classifies the request and selects the right algorithm + difficulty."""

    def analyze(self, text: str) -> TaskAnalysis:
        t = text.lower().strip()

        # --- Easy ---
        if self._is_greeting(t):
            return TaskAnalysis(
                TaskType.GREETING, Difficulty.EASY,
                steps=["Respond naturally"],
                reason="Simple greeting"
            )

        if any(w in t for w in ["who are you", "what are you", "what can you do", "your name"]):
            return TaskAnalysis(
                TaskType.IDENTITY, Difficulty.EASY,
                steps=["State identity and capabilities"],
                reason="Identity / capability question"
            )

        if self._is_calc(t):
            return TaskAnalysis(
                TaskType.CALCULATION, Difficulty.EASY,
                steps=["Extract expression", "Compute deterministically", "Return result"],
                reason="Arithmetic request"
            )

        # --- Medium ---
        if self._needs_web(t):
            return TaskAnalysis(
                TaskType.RESEARCH, Difficulty.MEDIUM,
                needs_web=True,
                steps=[
                    "Extract clean search query",
                    "Call web search tool",
                    "Collect real sources",
                    "Summarize with citations",
                    "State uncertainty if sources are weak"
                ],
                reason="Requires external information"
            )

        if any(w in t for w in ["explain", "what is", "how does", "how do", "difference between", "why", "compare", "vs ", "versus", "what are the steps", "how to implement"]):
            return TaskAnalysis(
                TaskType.EXPLANATION, Difficulty.MEDIUM,
                needs_web=True,
                steps=[
                    "Identify the concept",
                    "Research for accuracy when needed",
                    "Give clear structured explanation",
                    "Note limits of knowledge"
                ],
                reason="Explanation / comparison request"
            )

        if any(w in t for w in ["design the architecture", "architecture for", "design a system", "system design"]):
            return TaskAnalysis(
                TaskType.PLANNING, Difficulty.HARD,
                needs_plan=True,
                needs_web=True,
                steps=[
                    "Clarify system goals and constraints",
                    "Identify major components",
                    "Define interfaces and data flow",
                    "Note tools, memory, and model roles",
                    "List risks and verification points"
                ],
                reason="System / architecture design"
            )

        if any(w in t for w in ["my preference", "what do i like", "my definition", "remember that"]):
            return TaskAnalysis(
                TaskType.MEMORY, Difficulty.MEDIUM,
                needs_memory=True,
                steps=["Read local user memory", "Return relevant stored info"],
                reason="Memory / preference query"
            )

        # --- Hard ---
        if any(w in t for w in ["plan", "steps to", "how to build", "roadmap", "strategy"]):
            return TaskAnalysis(
                TaskType.PLANNING, Difficulty.HARD,
                needs_plan=True,
                steps=[
                    "Clarify the goal",
                    "Break into ordered steps",
                    "Identify required tools or research",
                    "Produce actionable plan",
                    "Note assumptions"
                ],
                reason="Multi-step planning"
            )

        # --- Expert ---
        if any(w in t for w in ["build", "create app", "make a game", "develop", "implement", "code a"]):
            return TaskAnalysis(
                TaskType.BUILD, Difficulty.EXPERT,
                needs_plan=True,
                needs_web=True,
                steps=[
                    "Understand product requirements",
                    "Choose architecture",
                    "Break into components",
                    "Research any needed APIs/docs",
                    "Outline files and logic",
                    "Describe testing approach",
                    "State what can be done now vs later"
                ],
                reason="Application / game / system building"
            )

        # Default
        return TaskAnalysis(
            TaskType.UNKNOWN, Difficulty.MEDIUM,
            steps=["Assess understanding", "Answer if possible", "Otherwise state limits clearly"],
            reason="Unclassified request"
        )

    def _is_greeting(self, t: str) -> bool:
        return t in ("hi", "hello", "hey", "yo", "good morning", "good evening") or (
            len(t) < 15 and any(g in t for g in ["hello", "hi ", "hey"])
        )

    def _is_calc(self, t: str) -> bool:
        # Strict: only pure arithmetic-style requests, not prose that happens to contain - or /
        if not re.search(r"\d", t):
            return False
        # Must look like a math expression, not English
        cleaned = re.sub(r"(?i)(calculate|compute|what is|whats|eval)\s*", "", t).strip()
        return bool(re.fullmatch(r"[\d\s\+\-\*/\(\)\.\^%]+", cleaned))

    def _needs_web(self, t: str) -> bool:
        triggers = [
            "search", "look up", "research", "find information", "what is the latest",
            "current", "who is", "news about", "according to", "website", "online",
            "difference between", "compare", "vs ", " versus ", "how does", "how do",
            "explain", "what are the steps", "how to implement", "architecture for",
        ]
        return any(w in t for w in triggers)


# Difficulty → behavior modifiers
DIFFICULTY_CONFIG = {
    Difficulty.EASY: {
        "max_steps": 2,
        "use_web": False,
        "require_plan": False,
        "style": "short and direct",
    },
    Difficulty.MEDIUM: {
        "max_steps": 5,
        "use_web": True,
        "require_plan": False,
        "style": "clear and structured",
    },
    Difficulty.HARD: {
        "max_steps": 8,
        "use_web": True,
        "require_plan": True,
        "style": "detailed plan + reasoning",
    },
    Difficulty.EXPERT: {
        "max_steps": 12,
        "use_web": True,
        "require_plan": True,
        "style": "full architecture + steps + verification notes",
    },
}
