"""
Structured knowledge for smarter answers without external APIs.
Used by the brain for common technical questions.
"""
from __future__ import annotations
from typing import Optional
import re

KB = [
    {
        "keys": ["encoder-decoder", "encoder decoder", "seq2seq"],
        "answer": (
            "**Encoder–decoder vs decoder-only**\n\n"
            "• **Encoder–decoder**: The encoder reads the full input and builds a representation. "
            "The decoder generates the output while attending to that representation (cross-attention). "
            "Classic use: translation, summarization, input→structured output.\n"
            "• **Decoder-only**: One stack generates left-to-right. It uses causal self-attention only. "
            "Classic use: ChatGPT-style chat, code completion, open-ended generation.\n\n"
            "Modern large chat models are mostly **decoder-only**. Encoder–decoder is still strong when "
            "you have a clear source sequence and target sequence."
        ),
    },
    {
        "keys": ["attention", "multi-head", "self-attention", "causal mask"],
        "answer": (
            "**Attention (how it works)**\n\n"
            "1. Each token makes a **Query (Q)**, **Key (K)**, and **Value (V)** vector.\n"
            "2. Scores = Q · Kᵀ / √d  (scaled dot-product).\n"
            "3. Softmax turns scores into weights; output = weighted sum of V.\n"
            "4. **Multi-head**: several QKV sets in parallel, then concatenated.\n"
            "5. **Causal mask**: blocks attending to future positions (needed for generation).\n"
            "6. **Cross-attention** (encoder–decoder): decoder Q attends to encoder K/V.\n\n"
            "Attention lets the model focus on relevant context instead of treating all tokens equally."
        ),
    },
    {
        "keys": ["backpropagation", "backprop", "gradient", "train neural"],
        "answer": (
            "**Training a neural network**\n\n"
            "1. Forward pass → predictions.\n"
            "2. Loss measures error vs target.\n"
            "3. Backpropagation computes gradients of loss w.r.t. each weight.\n"
            "4. Optimizer (e.g. AdamW) updates weights to reduce loss.\n"
            "5. Repeat over batches/epochs; validate on held-out data.\n\n"
            "Saving a checkpoint stores the learned weights so inference can reuse them."
        ),
    },
    {
        "keys": ["onnx", "transformers.js", "browser inference", "webgpu"],
        "answer": (
            "**Running models in the browser**\n\n"
            "HAxBRO already uses **Transformers.js** with ONNX weights (SmolLM2, Gemma-class models).\n"
            "Flow: download quantized ONNX → WebGPU if available else WASM CPU → text-generation pipeline.\n"
            "A separate Python brain (like HAxBRO Brain) usually runs as a **server-side provider**, "
            "not inside the browser, unless exported to a compatible ONNX graph."
        ),
    },
    {
        "keys": ["api key", "without api", "no api", "own brain", "own model"],
        "answer": (
            "**Own brain, no API keys**\n\n"
            "HAxBRO Brain is a local neural model with its own trained weights. "
            "Core chat, planning, and algorithms do **not** need OpenAI/Gemini/HF Inference keys.\n"
            "Optional external models can still be added later for hard tasks, but they are not required "
            "for the core intelligence path."
        ),
    },
    {
        "keys": ["app maker", "build app", "build game", "snake"],
        "answer": (
            "**Building products with intelligence**\n\n"
            "Good flow:\n"
            "1. Clarify product type and must-have features.\n"
            "2. Plan architecture (UI, state, logic, data).\n"
            "3. Generate real files (not only a title screen).\n"
            "4. Preview and test the main user path.\n"
            "5. Fix failures; only then call it done.\n\n"
            "In HAxBRO, App Maker should call the brain for planning and the native/builder path for files, "
            "then verify the result actually runs."
        ),
    },
]


def lookup(text: str) -> Optional[str]:
    t = text.lower()
    best = None
    best_hits = 0
    for item in KB:
        hits = sum(1 for k in item["keys"] if k in t)
        if hits > best_hits:
            best_hits = hits
            best = item["answer"]
    return best if best_hits > 0 else None
