"""
Multi-user local memory for HAxBRO Brain.
Empty by default. Owner wires real data later.
Isolated per user.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional
from datetime import datetime, timezone
import json
from pathlib import Path


@dataclass
class UserProfile:
    user_id: str
    preferences: Dict[str, Any] = field(default_factory=dict)   # likes / dislikes
    definitions: Dict[str, str] = field(default_factory=dict)  # user-defined terms
    notes: List[str] = field(default_factory=list)
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class LocalMemory:
    def __init__(self, path: str = "data/memory.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.users: Dict[str, UserProfile] = {}
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                for uid, pdata in data.get("users", {}).items():
                    self.users[uid] = UserProfile(**pdata)
            except Exception:
                pass

    def _save(self):
        data = {"users": {uid: asdict(p) for uid, p in self.users.items()}}
        self.path.write_text(json.dumps(data, indent=2))

    def get_or_create(self, user_id: str) -> UserProfile:
        if user_id not in self.users:
            self.users[user_id] = UserProfile(user_id=user_id)
            self._save()
        return self.users[user_id]

    def set_preference(self, user_id: str, key: str, value: Any):
        profile = self.get_or_create(user_id)
        profile.preferences[key] = value
        profile.updated_at = datetime.now(timezone.utc).isoformat()
        self._save()

    def add_definition(self, user_id: str, term: str, definition: str):
        profile = self.get_or_create(user_id)
        profile.definitions[term] = definition
        profile.updated_at = datetime.now(timezone.utc).isoformat()
        self._save()

    def get_context_for_user(self, user_id: str) -> str:
        """Return a short text summary of what we know about the user."""
        if user_id not in self.users:
            return "No stored preferences or definitions for this user yet."
        p = self.users[user_id]
        parts = []
        if p.preferences:
            parts.append("Preferences: " + ", ".join(f"{k}={v}" for k, v in p.preferences.items()))
        if p.definitions:
            parts.append("Definitions: " + "; ".join(f"{k}: {v}" for k, v in p.definitions.items()))
        if p.notes:
            parts.append("Notes: " + " | ".join(p.notes[-5:]))
        return "\n".join(parts) if parts else "No stored preferences or definitions for this user yet."
