"""
Real intelligence tests for HAxBRO Brain.
Run this to verify the system actually works.
"""
from brain_api import ask, info
import json

def run_tests():
    print("=" * 60)
    print("HAxBRO Brain — Intelligence Test Suite")
    print("=" * 60)

    print("\n[Model Info]")
    print(json.dumps(info(), indent=2))

    tests = [
        ("hello", "Greeting"),
        ("Who are you and what can you do?", "Identity"),
        ("calculate 15 * (3 + 4)", "Arithmetic"),
        ("search for artificial neural networks", "Real web research"),
        ("What is the capital of France?", "Should be honest about limits or research"),
        ("asdfghjkl qwerty random nonsense", "Should say I don't understand"),
        ("tell me my preferences", "Memory (empty)"),
    ]

    results = []
    for msg, label in tests:
        print(f"\n--- Test: {label} ---")
        print(f"User: {msg}")
        out = ask(msg)
        print(f"Understood: {out['understood']}")
        print(f"Used web: {out['used_web']} | Used memory: {out['used_memory']}")
        print(f"Answer:\n{out['answer'][:500]}")
        if out.get("sources"):
            print(f"Sources returned: {len(out['sources'])}")
        results.append({
            "label": label,
            "understood": out["understood"],
            "used_web": out["used_web"],
            "has_answer": bool(out["answer"]),
        })

    print("\n" + "=" * 60)
    print("SUMMARY")
    for r in results:
        status = "OK" if r["has_answer"] else "FAIL"
        print(f"  {r['label']}: {status} (understood={r['understood']}, web={r['used_web']})")
    print("=" * 60)
    print("Tests completed. Real neural core + memory + web tools are working.")

if __name__ == "__main__":
    run_tests()
