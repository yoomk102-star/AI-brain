"""
Public API for HAxBRO Brain.
- ask / info  → used by UI and simple callers
- provider    → used by HAxBRO main app for embedding
"""
from core.provider import get_provider

def get_brain():
    # One shared Brain instance prevents duplicate model allocations and split memory.
    return get_provider()._brain

def ask(message: str, user_id: str = "default", session_id: str = "default") -> dict:
    return get_brain().think(message, user_id=user_id, session_id=session_id)

def info() -> dict:
    return get_provider().info()
