from core.brain import Brain


def test_bundled_checkpoint_loads():
    brain = Brain()
    assert brain.checkpoint_loaded is True
    info = brain.info()['neural']
    assert info['parameters'] == 1_563_520
    assert info['vocab_size'] == 41


def test_safe_arithmetic():
    brain = Brain()
    assert brain._calc('calculate 25 * 8')[0].startswith('**200**')
    assert brain._calc('calculate (2 + 3) * 4')[0].startswith('**20**')
    assert brain._calc('calculate 10 / 0')[1] is False
    assert brain._calc('__import__("os").system("whoami")')[1] is False


def test_chat_response_shape():
    brain = Brain()
    result = brain.think('hi', user_id='test-user', session_id='test-session')
    assert isinstance(result['answer'], str) and result['answer']
    assert 'model_info' in result
    assert result['model_info']['checkpoint_loaded'] is True
