"""Train a HAxBRO-owned byte-level Transformer from a plain-text corpus.

Example:
  python train_model.py --data data/training.txt --steps 2000 --out checkpoints/haxbro_brain_trained.pt

This is a small experimental trainer, not a shortcut to frontier-level intelligence.
Use licensed/consented data, a validation set, and suitable compute for larger runs.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import torch

from core.model import HaxbroBrain


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', required=True, help='UTF-8 plain-text training corpus')
    parser.add_argument('--out', default='checkpoints/haxbro_brain_trained.pt')
    parser.add_argument('--steps', type=int, default=2000)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--block-size', type=int, default=128)
    parser.add_argument('--dim', type=int, default=256)
    parser.add_argument('--layers', type=int, default=6)
    parser.add_argument('--heads', type=int, default=8)
    parser.add_argument('--lr', type=float, default=3e-4)
    parser.add_argument('--eval-every', type=int, default=100)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    if args.steps < 1 or args.batch_size < 1 or args.block_size < 8:
        parser.error('steps/batch-size must be positive and block-size must be >= 8')
    if args.dim % args.heads:
        parser.error('--dim must be divisible by --heads')

    text = Path(args.data).read_text(encoding='utf-8')
    raw = torch.tensor(list(text.encode('utf-8')), dtype=torch.long)
    if len(raw) < args.block_size + 2:
        parser.error('training corpus is too small for this block size')
    split = max(args.block_size + 1, int(len(raw) * 0.9))
    train_data = raw[:split]
    val_data = raw[split:] if len(raw) - split > args.block_size else raw[:split]
    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = HaxbroBrain(vocab_size=256, n_embd=args.dim, n_head=args.heads,
                        n_layer=args.layers, block_size=args.block_size).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)

    def batch(source):
        max_start = len(source) - args.block_size - 1
        starts = torch.randint(0, max_start + 1, (args.batch_size,))
        x = torch.stack([source[int(i):int(i) + args.block_size] for i in starts]).to(device)
        y = torch.stack([source[int(i) + 1:int(i) + args.block_size + 1] for i in starts]).to(device)
        return x, y

    def evaluate(source):
        model.eval()
        with torch.no_grad():
            x, y = batch(source)
            _, loss = model(x, y)
        model.train()
        return float(loss.item())

    model.train()
    for step in range(1, args.steps + 1):
        x, y = batch(train_data)
        _, loss = model(x, y)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if step == 1 or step % args.eval_every == 0 or step == args.steps:
            val_loss = evaluate(val_data)
            print(f'step={step}/{args.steps} train_loss={loss.item():.4f} val_loss={val_loss:.4f}')

    cfg = {
        'vocab_size': 256, 'n_embd': args.dim, 'n_head': args.heads,
        'n_layer': args.layers, 'block_size': args.block_size,
        'tokenizer': 'utf8-byte-level',
    }
    final_val_loss = evaluate(val_data)
    parameter_count = model.count_parameters()
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({'model_state': model.cpu().state_dict(), 'config': cfg,
                'train_meta': {'steps': args.steps, 'parameters': parameter_count,
                               'final_train_loss': float(loss.item()),
                               'final_validation_loss': final_val_loss,
                               'status': 'trained_experimentally'}}, output)
    print(f'Saved checkpoint: {output} ({parameter_count:,} parameters; validation loss {final_val_loss:.4f})')
    print('Note: training loss alone does not demonstrate general intelligence.')

if __name__ == '__main__':
    main()
