# Deploy and test HAxBRO Prototype AI Model

## A. Publish the interface on GitHub Pages

1. Extract the ZIP.
2. Upload the **contents** of the `haxbro-brain` folder to the root of your repository. The repository root must contain `index.html`, `README.md`, `run_server.py`, `requirements.txt`, `core/`, and `checkpoints/`.
3. In GitHub: **Settings → Pages → Deploy from a branch → main → /(root)**.
4. Wait for the Pages deployment to show a green check. Open `https://yoomk102-star.github.io/AI-brain/`.

The static UI should load. The status initially reads `API not connected` until a backend URL is configured.

## B. Run the full backend

GitHub Pages cannot execute Python/PyTorch. Run this project on a Python-capable host or a computer/server you control:

```bash
pip install -r requirements.txt
python run_server.py
```

Check `/api/health` on that backend. Use its public HTTPS base URL in the UI's **API endpoint** setting. The backend must be reachable from the browser and allow CORS. Never use a private/local-only URL as a public production endpoint.

## C. Smoke test

```bash
python -m pytest -q
python run_server.py
```

In another terminal, check `GET /api/health`, `GET /api/info`, and send `POST /api/chat` with JSON `{"message":"calculate 25 * 8","session_id":"smoke-test"}`.

## Limits and security

This is an experimental ~1.56M-parameter model plus deterministic tools/routing, not a ChatGPT-level model. Do not expose it publicly without authentication, rate limiting, session isolation, and appropriate secrets handling. No hosted model API is required.
