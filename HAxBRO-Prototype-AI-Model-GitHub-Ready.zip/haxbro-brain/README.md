# HAxBRO Prototype AI Model

An experimental self-owned AI project package containing a browser chat interface, Python HTTP API/backend, bundled small neural checkpoint, task utilities, local conversation memory, web-research tool, training starter, and tests. It does **not** call ChatGPT, Grok, Gemini, or another hosted model API.

## What works in this prototype

- Chat UI at `index.html` (also served from `ui/index.html` by the Python server).
- Python backend routes: `/api/health`, `/api/info`, `/api/chat`, and `/v1/brain/ask`.
- Bundled checkpoint loading, supported deterministic utilities, basic conversation context, and optional web research.
- A starter training script and smoke/unit tests.

## Important deployment truth

**Uploading this ZIP to GitHub Pages alone will not run the AI backend.** GitHub Pages is static hosting; it can serve `index.html`, CSS, and browser JavaScript, but it does not execute Python or PyTorch. The interface therefore shows `API not connected` until it is configured to call your own running backend.

To get full chat functionality, deploy this complete repository to a Python-capable host (or run it on a computer/server you control), install `requirements.txt`, and start `python run_server.py`. Then open the GitHub Pages UI, tap **API endpoint**, and enter the backend's HTTPS base URL. The backend must allow browser CORS requests. Do not expose a public unauthenticated service with private data.

## Run locally

Python 3.10+ recommended:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
python run_server.py
```

Open `http://127.0.0.1:8080`. Check `http://127.0.0.1:8080/api/health`.

## Upload to GitHub from a phone

1. Extract this ZIP.
2. Open the extracted `haxbro-brain` folder.
3. Upload **the contents of that folder** to the root of `yoomk102-star/AI-brain`, not the enclosing folder. `index.html` and `README.md` must be visible on the repository's main Code page.
4. In repository **Settings → Pages**, publish branch `main`, folder `/(root)`.
5. Wait for the Pages deployment to succeed. The interface should load at `https://yoomk102-star.github.io/AI-brain/`.
6. For backend chat, separately run/deploy the Python backend as described above and set its HTTPS URL using **API endpoint** in the UI.

## Model limitations

The included checkpoint is a small experimental character-level Transformer of about 1.56M parameters, with metadata reporting 250 training steps. It is **not** comparable to ChatGPT/Grok and does not independently deliver broad general intelligence. The runtime also uses deterministic routing for supported tasks; the bundled checkpoint is not a general-purpose assistant by itself. Improving it requires substantial quality data, training, evaluation, and compute.

## Files

- `index.html`: GitHub Pages homepage.
- `ui/index.html`: same chat UI, served by the Python backend.
- `run_server.py`, `server.py`, `brain_api.py`: HTTP backend and API.
- `core/`: model, routing, provider, and algorithms.
- `checkpoints/haxbro_brain_trained.pt`: bundled model checkpoint.
- `tools/`, `memory/`: research and local memory utilities.
- `train_model.py`, `TRAINING.md`: training starter and notes.
- `tests/`: tests.

This is a prototype, not a production-secure public service. Add authentication, rate limiting, robust user/session isolation, and secrets management before public use.
