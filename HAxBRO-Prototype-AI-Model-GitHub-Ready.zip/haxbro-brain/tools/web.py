"""Real web tools for HAxBRO Brain. No fabricated sources."""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime, timezone
import httpx
from bs4 import BeautifulSoup
import re
from urllib.parse import urlparse, unquote


@dataclass
class Source:
    title: str
    url: str
    domain: str
    excerpt: str
    retrieved_at: str


@dataclass
class SearchResult:
    query: str
    sources: List[Source]
    status: str          # ok | error | empty
    error: Optional[str] = None


class WebTools:
    def __init__(self, timeout: float = 12.0):
        self.client = httpx.Client(
            timeout=timeout,
            follow_redirects=True,
            headers={"User-Agent": "HAxBRO-Brain/0.1 (research agent)"}
        )

    def search(self, query: str, max_results: int = 5) -> SearchResult:
        if not query or not query.strip():
            return SearchResult(query=query, sources=[], status="error", error="Empty query")
        try:
            resp = self.client.get("https://html.duckduckgo.com/html/", params={"q": query})
            if resp.status_code != 200:
                return SearchResult(query=query, sources=[], status="error", error=f"HTTP {resp.status_code}")
            soup = BeautifulSoup(resp.text, "html.parser")
            sources = []
            now = datetime.now(timezone.utc).isoformat()
            for r in soup.select(".result")[:max_results]:
                a = r.select_one("a.result__a")
                snip = r.select_one(".result__snippet")
                if not a:
                    continue
                href = a.get("href", "")
                title = a.get_text(strip=True)
                excerpt = snip.get_text(" ", strip=True) if snip else ""
                if "uddg=" in href:
                    m = re.search(r"uddg=([^&]+)", href)
                    if m:
                        href = unquote(m.group(1))
                domain = urlparse(href).netloc if href.startswith("http") else ""
                if title and href.startswith("http"):
                    sources.append(Source(
                        title=title[:200],
                        url=href[:500],
                        domain=domain,
                        excerpt=excerpt[:350],
                        retrieved_at=now,
                    ))
            status = "ok" if sources else "empty"
            return SearchResult(query=query, sources=sources, status=status)
        except Exception as e:
            return SearchResult(query=query, sources=[], status="error", error=str(e))

    def close(self):
        self.client.close()
