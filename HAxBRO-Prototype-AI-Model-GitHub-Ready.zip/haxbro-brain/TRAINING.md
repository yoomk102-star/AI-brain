# Training notes

The bundled `checkpoints/haxbro_brain_trained.pt` contains a checkpoint dictionary with `model_state`, `config`, and `train_meta`. The architecture and character vocabulary are read from the checkpoint config at runtime. The metadata reports 250 training steps, approximately 1.56M parameters, initial loss ~3.72 and final loss ~0.94. These numbers describe this training run only; they do not establish broad language competence.

## Safe next steps

1. Inspect the training corpus and confirm you have rights to use it.
2. Keep a reproducible train/validation split and report validation loss, not only training loss.
3. Add tests for language generation, memorization, tool routing, factuality, and multi-turn context.
4. Save tokenizer/config metadata with every checkpoint.
5. Compare each new checkpoint against a fixed evaluation set before replacing the current one.
6. Use appropriate GPU/accelerator infrastructure for larger training runs; Netlify is not a model-training environment.

Do not claim the model is equivalent to large commercial assistants without evidence from broad, independent evaluations.
