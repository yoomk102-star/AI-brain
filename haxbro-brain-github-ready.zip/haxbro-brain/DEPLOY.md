# Deploy and test HAxBRO Brain

## 1. Local test (recommended first)

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run_server.py
```

Open `http://127.0.0.1:8080`. Verify `GET /api/health` and try arithmetic, a greeting, and a web-research request.

## 2. Upload to GitHub

Create a repository and upload the contents of this folder. The `README.md` must be at repository root. Keep the model checkpoint in `checkpoints/`.

## 3. Netlify limitation

The current backend is a Python HTTP server using PyTorch. Netlify static hosting does not run that server. This project is **not** a one-click full-backend Netlify deployment. Netlify can host the UI, but it must be configured to call your own separately hosted Brain API. For an all-in-one test, run the server on a Python-capable host. No hosted model API is required.

## 4. Before making it public

Add authentication, per-user/session isolation, request-size limits, rate limiting, and deployment secrets management. The current prototype is intended for controlled testing.
