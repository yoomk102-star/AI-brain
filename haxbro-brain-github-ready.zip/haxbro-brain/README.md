# HAxBRO Brain — experimental self-owned AI project

A GitHub-ready Python project for experimenting with a locally owned neural model, a conversational UI, deterministic utilities, local conversation memory, and web research. It does **not** call ChatGPT, Grok, Gemini, or another hosted model API.

## Important status

- The bundled checkpoint is a small character-level Transformer (about 1.56M trainable parameters), trained for 250 steps according to its metadata.
- The runtime now loads the checkpoint using the architecture and vocabulary stored with that checkpoint.
- This is an experimental starting point, **not** a ChatGPT/Grok-equivalent general-purpose model. The current chat includes deterministic routing for supported tasks; broad language intelligence needs more data, training, evaluation, and compute.
- Web search is a tool, not an external model service. Search availability depends on network access and upstream websites.
- Conversation memory is currently local to the server process/storage; do not expose a public instance without adding authentication, isolation, and rate limits.

## Run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python run_server.py
```

Open `http://127.0.0.1:8080`. Health: `GET /api/health`. Chat: `POST /api/chat` with `{"message":"Hi","session_id":"test"}`. Provider API: `POST /v1/brain/ask` with `{"prompt":"...","session_id":"test"}`.

## GitHub

Upload the contents of this folder as the repository root (the `README.md` should be visible at the root). Keep the checkpoint in `checkpoints/`; it is part of the model artifact. Do not upload secrets or private user data.

## Netlify note

Netlify can host a static UI, but this Python/PyTorch server and its checkpoint are not directly runnable as a standard static deployment. The working neural API needs a Python-capable host or a separately engineered compatible runtime. This repo includes `netlify.toml` as a deployment note/configuration for static UI experiments only; it does not claim the full neural backend runs on Netlify.

## Training

See `TRAINING.md` for checkpoint details and a starter plan for continued training. A small checkpoint cannot acquire broad reasoning merely by adding web search; training data, model design, and measured evaluation matter.
