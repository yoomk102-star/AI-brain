"""
HAxBRO Brain — HTTP Provider Server
Exposes the IntelligenceProvider contract so main HAxBRO can call it
like an embedded model (HF / Gemini style lane).

Endpoints:
  GET  /api/health
  GET  /api/info          → provider.info()
  GET  /api/available     → provider.is_available()
  POST /api/chat          → legacy chat (UI)
  POST /v1/brain/ask      → provider.ask_dict (integration contract)
  GET  /                  → chat UI
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json

from brain_api import ask, info
from core.provider import get_provider

UI_FILE = Path(__file__).parent / "ui" / "index.html"
provider = get_provider()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        print(f"[{self.address_string()}] {format % args}")

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/" or path == "/index.html":
            html = UI_FILE.read_text(encoding="utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self._cors()
            self.end_headers()
            self.wfile.write(html.encode("utf-8"))
        elif path == "/api/info" or path == "/v1/brain/info":
            self._json(provider.info())
        elif path == "/api/available" or path == "/v1/brain/available":
            self._json({"id": provider.id, "available": provider.is_available()})
        elif path == "/api/health":
            self._json({
                "status": "ok",
                "service": "HAxBRO-Brain",
                "provider": provider.id,
                "available": provider.is_available(),
            })
        else:
            self.send_error(404)

    def do_POST(self):
        path = self.path.split("?")[0]
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(body.decode("utf-8") or "{}")
        except Exception:
            self._json({"ok": False, "error": "Invalid JSON"}, 400)
            return

        if path in ("/api/chat", "/v1/brain/ask", "/v1/ask"):
            # Provider contract path
            if path.startswith("/v1/"):
                result = provider.ask_dict(data)
                self._json(result)
            else:
                # UI chat path
                msg = (data.get("message") or data.get("prompt") or "").strip()
                uid = data.get("user_id") or data.get("username") or "default"
                sid = data.get("session_id") or data.get("kaiId") or "default"
                if not msg:
                    self._json({"error": "Empty message"}, 400)
                    return
                result = ask(msg, user_id=uid, session_id=sid)
                self._json(result)
        else:
            self.send_error(404)

    def _json(self, obj, code=200):
        payload = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors()
        self.end_headers()
        self.wfile.write(payload)


if __name__ == "__main__":
    port = 8080
    server = HTTPServer(("0.0.0.0", port), Handler)
    print(f"HAxBRO Brain Provider running at http://0.0.0.0:{port}")
    print("Integration endpoints:")
    print("  GET  /v1/brain/info")
    print("  GET  /v1/brain/available")
    print("  POST /v1/brain/ask")
    print("  GET  /api/health")
    print("Chat UI: http://127.0.0.1:8080/")
    server.serve_forever()
