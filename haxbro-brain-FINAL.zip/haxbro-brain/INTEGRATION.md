# HAxBRO Brain → Main HAxBRO Integration Guide

Based on the ChatGPT codebase audit of HAxBRO (proj_cPoy7TbTYZPq).

## Goal

Embed HAxBRO Brain as a real intelligence provider lane — same class of integration as Hugging Face / Gemini style providers — so the main assistant, App Maker, coding tools, research, and workspaces can call it.

## What Brain exposes (provider contract)

```
GET  /v1/brain/info
GET  /v1/brain/available
POST /v1/brain/ask
```

### POST /v1/brain/ask body

```json
{
  "prompt": "user message",
  "history": [{"role":"user","content":"..."}],
  "memory": "optional string",
  "task": "optional",
  "difficulty": "easy|medium|hard|expert",
  "user_id": "username",
  "session_id": "kaiId or session"
}
```

### Response

```json
{
  "ok": true,
  "response": "...",
  "provider": "haxbro-brain",
  "model": "HAxBRO-Brain-14343936",
  "elapsed_ms": 12.5,
  "sources": [{"title":"...","url":"...","excerpt":"..."}],
  "task_type": "build",
  "difficulty": "expert",
  "algorithm_steps": ["..."],
  "understood": true
}
```

## Where to plug into main HAxBRO (from audit)

1. **Router** — `public/kai51-local.js`  
   Register a new lane name: `"brain"` / `"kai-brain"` next to `local`, `github`, `largest`, `lite`.

2. **Capability bridge** — `public/kai-capability-bridge.js`  
   In `appMaker(...)` and `unified(...)`, allow selecting the brain provider for analysis / generation when configured.

3. **Do not** replace native recovery (`/api/appmaker-original-generate`) or disable existing lanes.

4. **Server synthesis** remains disabled by design (`lib/core.js` exception). Brain should be called as:
   - A separate Python HTTP service (recommended), OR
   - Later: ONNX export into browser (not done yet)

## Recommended runtime

```
HAxBRO Brain  →  long-running Python process on 0.0.0.0:8080
Main HAxBRO   →  server-side adapter calls POST /v1/brain/ask
Browser       →  existing Transformers.js lanes unchanged
```

## Verified capabilities

| Capability | Status |
|------------|--------|
| 14.3M real neural parameters | Yes |
| Attention (multi-head causal) | Yes |
| Easy→Expert algorithms | Yes |
| Live web research (DuckDuckGo) | Yes (verified sources returned) |
| Hard/Expert build & plan tasks | Yes |
| Provider HTTP contract | Yes |
| Fast answers (local path) | Yes (sub-ms for plan/calc) |
| App Maker file generation | Not in Brain — HAxBRO native path still required |

## What Brain does NOT replace

- Deterministic `lib/kai-native-builder.js` recovery
- Browser ONNX SmolLM2 / Gemma lanes
- ship.page publish flow
- Hatchable `ai.generateText` in the separate App Maker project

It sits **beside** those as another real provider.
