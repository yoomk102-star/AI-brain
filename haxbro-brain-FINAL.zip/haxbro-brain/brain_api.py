"""
Public API for HAxBRO Brain.
- ask / info  → used by UI and simple callers
- provider    → used by HAxBRO main app for embedding
"""
from core.brain import Brain
from core.provider import get_provider, HaxbroBrainProvider, BrainRequest, BrainResult

_brain = None

def get_brain() -> Brain:
    global _brain
    if _brain is None:
        _brain = Brain()
    return _brain

def ask(message: str, user_id: str = "default", session_id: str = "default") -> dict:
    return get_brain().think(message, user_id=user_id, session_id=session_id)

def info() -> dict:
    return get_provider().info()
