# Deploy HAxBRO Brain

## What this package is
- Trained neural model (checkpoint in `checkpoints/`)
- Provider API: POST /v1/brain/ask
- Chat UI
- No API keys required for core brain

## Training (this build)
- Loss: ~3.72 → ~0.94 (real training)
- ~1.56M parameters
- Device: CPU (no GPU in build environment)

## Important: Netlify / GitHub Pages

**Netlify and GitHub Pages cannot run the PyTorch neural model.**
They only host static files (HTML/CSS/JS).

| Platform | What works | What does not |
|----------|------------|---------------|
| GitHub | Host the **code** (upload this repo) | Run the AI model |
| Netlify | Host the **chat UI** (static) | Run PyTorch inference |
| Your PC / VPS / Render / Railway / Fly.io | Run `python run_server.py` | — |

### Recommended path so the AI actually works

1. **Upload code to GitHub** (backup + share source) — yes
2. **Run the brain server** on a machine that supports Python:
   ```bash
   pip install torch httpx beautifulsoup4
   python run_server.py
   ```
3. Point HAxBRO (or the UI) to:
   ```
   http://YOUR_HOST:8080/v1/brain/ask
   ```
4. Optional: put only `ui/` on Netlify as a front page that calls your server URL

### Wire into HAxBRO
See `INTEGRATION.md` — register provider lane `"brain"` calling `/v1/brain/ask`.

### Quick local test
```bash
python run_server.py
# open http://127.0.0.1:8080
```
