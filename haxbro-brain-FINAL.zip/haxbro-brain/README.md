# HAxBRO Brain

Real neural intelligence provider for HAxBRO.

## Specs
- **14,343,936** trainable parameters (decoder-only Transformer + attention)
- Difficulty algorithms: Easy / Medium / Hard / Expert
- Live web research
- Conversation + local memory
- **Provider API** for embedding into main HAxBRO (like HF/Gemini lanes)

## Run
```bash
python3 run_server.py
```

- Chat UI: http://127.0.0.1:8080/
- Provider: POST http://127.0.0.1:8080/v1/brain/ask

## Integration
See `INTEGRATION.md` — maps to real HAxBRO files from the codebase audit
(`kai51-local.js`, `kai-capability-bridge.js`, App Maker paths).
