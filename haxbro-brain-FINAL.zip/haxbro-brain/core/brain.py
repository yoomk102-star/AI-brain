"""
HAxBRO Brain - Conversational intelligence layer
Real neural core + algorithms + difficulty + conversation memory + web tools.
Designed for direct chat.
"""
from __future__ import annotations
from typing import Dict, Any, Optional, List
from pathlib import Path
import re
import torch

from core.model import HaxbroBrain
from core.algorithms import TaskAnalyzer, TaskAnalysis, Difficulty, TaskType, DIFFICULTY_CONFIG
from core.conversation import ConversationMemory
from memory.store import LocalMemory
from tools.web import WebTools, SearchResult
from core.knowledge import lookup


class Brain:
    def __init__(self, checkpoint_dir: str = "checkpoints"):
        self.memory = LocalMemory()
        self.conversation = ConversationMemory(max_turns=24)
        self.web = WebTools()
        self.analyzer = TaskAnalyzer()
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.model = HaxbroBrain(
            vocab_size=128, n_embd=384, n_head=6, n_layer=8, block_size=256,
        )
        self.device = torch.device("cpu")
        self.model.to(self.device)
        self.model.eval()

    def info(self) -> Dict[str, Any]:
        return {
            "name": "HAxBRO-Brain",
            "version": "0.3",
            "neural": self.model.get_info(),
            "algorithms": ["task classification", "difficulty levels", "step planning", "conversation context"],
            "difficulty_levels": ["easy", "medium", "hard", "expert"],
            "memory": {
                "persistent": "multi-user local (empty until owner wires data)",
                "conversation": "session working memory (last 24 turns)",
            },
            "tools": ["web_search", "local_memory", "conversation_memory"],
            "behavior": "direct conversation · honest when unsure",
        }

    def think(self, user_message: str, user_id: str = "default", session_id: str = "default") -> Dict[str, Any]:
        msg = user_message.strip()
        if not msg:
            return self._out("Please type a message.", understood=False)

        # Conversation context
        recent = self.conversation.recent(session_id, n=6)
        self.conversation.add(session_id, "user", msg)

        analysis = self.analyzer.analyze(msg)
        config = DIFFICULTY_CONFIG[analysis.difficulty]
        memory_context = self.memory.get_context_for_user(user_id)
        used_memory = "No stored" not in memory_context

        # --- Easy paths ---
        if analysis.task_type == TaskType.GREETING:
            answer = self._greeting(recent)
            return self._finish(session_id, answer, True, analysis, used_memory=used_memory)

        if analysis.task_type == TaskType.IDENTITY:
            answer = self._identity()
            return self._finish(session_id, answer, True, analysis)

        if analysis.task_type == TaskType.CALCULATION:
            answer, ok = self._calc(msg)
            return self._finish(session_id, answer, ok, analysis)

        # --- Hard / Expert: planning & building ---
        if analysis.task_type in (TaskType.PLANNING, TaskType.BUILD) or analysis.needs_plan:
            answer = self._plan(analysis)
            return self._finish(session_id, answer, True, analysis)

        # --- Research ---
        # Prefer local structured knowledge for known technical topics
        if analysis.task_type in (TaskType.EXPLANATION, TaskType.UNKNOWN, TaskType.RESEARCH):
            kb = lookup(msg)
            if kb:
                return self._finish(session_id, kb, True, analysis)

        if analysis.task_type == TaskType.RESEARCH or analysis.needs_web:
            answer, sources, ok = self._research(msg)
            return self._finish(session_id, answer, ok, analysis, used_web=True, sources=sources)

        # --- Memory ---
        if analysis.task_type == TaskType.MEMORY:
            answer = f"From local memory:\n{memory_context}"
            return self._finish(session_id, answer, True, analysis, used_memory=True)

        # --- Conversational / general ---
        answer = self._converse(msg, recent, analysis)
        understood = analysis.task_type != TaskType.UNKNOWN or self._looks_coherent(msg)
        return self._finish(session_id, answer, understood, analysis, used_memory=used_memory)

    # ---------- response helpers ----------

    def _greeting(self, recent: List[Dict]) -> str:
        if recent:
            return "Hey again. What would you like to work on?"
        return (
            "Hey. I'm HAxBRO Brain.\n"
            "I have a real neural core (14.3M parameters), difficulty-based algorithms, "
            "conversation memory, and web tools.\n"
            "Talk to me normally — ask, research, plan, or build."
        )

    def _identity(self) -> str:
        info = self.model.get_info()
        return (
            f"I'm **HAxBRO Brain** — a real AI system you can talk to directly.\n\n"
            f"**Neural core:** {info['parameters']:,} trainable parameters "
            f"({info['n_layer']} layers, {info['n_embd']} dim)\n"
            f"**Algorithms:** Easy → Expert difficulty levels with different strategies\n"
            f"**Memory:** Conversation memory (this chat) + local user memory (you can fill later)\n"
            f"**Tools:** Live web research\n\n"
            f"I answer clearly. If I don't know something, I say so."
        )

    def _calc(self, msg: str) -> tuple:
        try:
            expr = re.sub(r"[^0-9\+\-\*/\(\)\.\s]", "", msg).strip()
            if not expr:
                return "I need a clearer math expression.", False
            result = eval(expr, {"__builtins__": {}}, {})
            return f"**{result}**\n\n_Calculated with a deterministic algorithm (Easy level)._", True
        except Exception:
            return "I couldn't safely evaluate that.", False

    def _plan(self, analysis: TaskAnalysis) -> str:
        lines = [
            f"**{analysis.task_type.value.upper()}** · Difficulty: **{analysis.difficulty.value}**",
            f"_{analysis.reason}_",
            "",
            "**Execution plan:**",
        ]
        for i, step in enumerate(analysis.steps, 1):
            lines.append(f"{i}. {step}")
        lines.append("")
        if analysis.difficulty == Difficulty.EXPERT:
            lines.extend([
                "**Expert product blueprint:**",
                "• Components: UI layer, state/logic, data, optional API",
                "• Interactions: inputs, transitions, error states, mobile layout",
                "• Verification: build check, core user flow, edge cases",
                "• Delivery: self-contained HTML/JS first; split files if needed",
                "",
                "Next: give a concrete product name or constraints and I will tighten",
                "the architecture into implementable modules for App Maker.",
            ])
        elif analysis.difficulty == Difficulty.HARD:
            lines.extend([
                "**Hard-mode notes:**",
                "• Ordered steps above are the working sequence",
                "• Call out assumptions and missing requirements early",
                "• Prefer measurable checkpoints over vague progress",
                "",
                "Say which step to expand and I will go deeper.",
            ])
        else:
            lines.append("I can refine any step — say which part.")
        return "\n".join(lines)

    def _research(self, msg: str) -> tuple:
        query = re.sub(
            r"(?i)(search for|look up|research|find information about|what is|who is)\s*",
            "", msg
        ).strip() or msg
        result: SearchResult = self.web.search(query, max_results=5)
        if result.status == "ok" and result.sources:
            lines = [f"I searched for **{query}**:\n"]
            sources = []
            for i, s in enumerate(result.sources, 1):
                lines.append(f"**{i}. {s.title}**\n{s.excerpt[:220]}...\n🔗 {s.url}\n")
                sources.append({"title": s.title, "url": s.url, "domain": s.domain, "excerpt": s.excerpt})
            lines.append("_Sources are live from the web._")
            return "\n".join(lines), sources, True
        return (
            f"I tried to research “{query}” but couldn't get reliable results "
            f"({result.error or result.status}). I don't want to guess.",
            [], False
        )

    def _converse(self, msg: str, recent: List[Dict], analysis: TaskAnalysis) -> str:
        """Natural conversation path — knowledge first, then honest limits."""
        lower = msg.lower()

        # Structured knowledge (makes the brain feel smarter on core topics)
        kb = lookup(msg)
        if kb:
            return kb

        if recent and any(w in lower for w in ["yes", "ok", "continue", "go on", "next", "more"]):
            return (
                "Continuing from the last topic.\n"
                "Give the next concrete step, or ask me to research / plan / build something specific."
            )

        if any(w in lower for w in ["thanks", "thank you", "cool", "nice"]):
            return "You're welcome. What should we tackle next?"

        if any(w in lower for w in ["help", "what can you"]):
            return self._identity()

        if analysis.difficulty in (Difficulty.EASY, Difficulty.MEDIUM):
            return (
                f"I classified this as **{analysis.task_type.value}** "
                f"(difficulty: {analysis.difficulty.value}).\n\n"
                "I can:\n"
                "• Explain attention, transformers, training, App Maker flow\n"
                "• **Search** the web for live sources\n"
                "• **Plan** or **build** (hard/expert algorithms)\n"
                "• Calculate deterministically\n\n"
                "Ask a direct question or say research / plan / build."
            )

        return (
            f"Classified as **{analysis.task_type.value}** / **{analysis.difficulty.value}**.\n"
            "I don't have a reliable full answer from current knowledge and tools. "
            "Ask me to **research** it, or rephrase with more detail."
        )

    def _looks_coherent(self, msg: str) -> bool:
        return len(msg) > 2 and not re.fullmatch(r"[^a-zA-Z0-9]+", msg)

    def _finish(
        self,
        session_id: str,
        answer: str,
        understood: bool,
        analysis: TaskAnalysis,
        used_web: bool = False,
        used_memory: bool = False,
        sources: Optional[List] = None,
    ) -> Dict[str, Any]:
        self.conversation.add(
            session_id, "assistant", answer,
            difficulty=analysis.difficulty.value,
            task_type=analysis.task_type.value,
        )
        return self._out(
            answer,
            understood=understood,
            analysis=analysis,
            used_web=used_web,
            used_memory=used_memory,
            sources=sources or [],
        )

    def _out(
        self,
        answer: str,
        understood: bool = True,
        analysis: Optional[TaskAnalysis] = None,
        used_web: bool = False,
        used_memory: bool = False,
        sources: Optional[List] = None,
    ) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "answer": answer,
            "understood": understood,
            "used_web": used_web,
            "used_memory": used_memory,
            "sources": sources or [],
            "model_info": self.model.get_info(),
        }
        if analysis:
            out["task_type"] = analysis.task_type.value
            out["difficulty"] = analysis.difficulty.value
            out["algorithm_steps"] = analysis.steps
            out["reason"] = analysis.reason
        return out

    def close(self):
        self.web.close()
