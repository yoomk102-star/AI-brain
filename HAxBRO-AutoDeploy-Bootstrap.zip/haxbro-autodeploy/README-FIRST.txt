HAxBRO PROTOTYPE AI MODEL — AUTO-PUBLISH PACKAGE

WHAT THIS DOES
- When the workflow is installed in your repository and you upload/replace haxbro-brain-source.zip at the repository root, GitHub Actions extracts it during deployment and publishes its index.html to GitHub Pages.
- The Python/PyTorch backend is included in the source ZIP but cannot run on GitHub Pages. This workflow publishes the static chat interface only.

ONE-TIME SETUP IS REQUIRED
GitHub will not activate a workflow hidden inside a ZIP uploaded as a single file. Install .github/workflows/pages.yml once, then future uploads of haxbro-brain-source.zip can trigger automatic publishing.

PHONE-FRIENDLY SETUP
1. Open https://github.com/yoomk102-star/AI-brain
2. Use Add file > Create new file.
3. In the filename box enter exactly: .github/workflows/pages.yml
4. Open the pages.yml file included in this package (or download the standalone pages.yml supplied with this package) and copy all of its text into the GitHub editor.
5. Commit the new file to branch main.
6. Open Settings > Pages. Under Build and deployment, choose Source: GitHub Actions if that choice is available.
7. Upload haxbro-brain-source.zip to the repository root using Add file > Upload files, and commit it. Keep this exact filename.
8. Open the Actions tab. Watch “Publish HAxBRO Prototype AI Model”. Wait for the green success check.
9. Open https://yoomk102-star.github.io/AI-brain/

IF A WORKFLOW RUN FAILS
Open Actions > the failed run > the failed step, and share a screenshot of the error.

IMPORTANT
This package does not deploy or host the Python/PyTorch backend. To make AI responses work through the backend, deploy the Python server separately to a Python-capable host, then set that server's HTTPS API endpoint in the UI. The current neural checkpoint is experimental and is not comparable to ChatGPT/Grok.
